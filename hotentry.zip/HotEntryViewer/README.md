# HotEntryViewer  

***

## What is this
ホッテントリを一覧表示してくれるChrome Extensionです．  

## Usage
ボタンを押すと，ホッテントリが一覧表示されます．  
Reloadボタンを押すことで，一覧を更新します．

## 今やりたいこと
* もう少し見やすいデザインを考える(style.css)
* タイマー機能を実装する(popup.js)
* ソート機能を実装する(popup.js)
